import sqlite3,json,re,os,collections
from pathlib import Path
SRC='/mnt/data/CivicPlAIn_NYC_unified.sqlite3'
OUT='/mnt/data/CivicPlAIn_standardized.sqlite3'
if os.path.exists(OUT): os.remove(OUT)
s=sqlite3.connect('file:'+SRC+'?mode=ro',uri=True);o=sqlite3.connect(OUT)
o.executescript('''PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF; PRAGMA temp_store=MEMORY;
CREATE TABLE metadata (key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE streets (street_key TEXT PRIMARY KEY,display_name TEXT,road_segments INTEGER DEFAULT 0,observations INTEGER DEFAULT 0,permits_on_street INTEGER DEFAULT 0,permits_other_mentions INTEGER DEFAULT 0,latest_rating REAL,latest_inspection_at TEXT,display_condition TEXT,display_basis TEXT);
CREATE TABLE roads(road_id TEXT PRIMARY KEY,street_key TEXT NOT NULL,street_name TEXT,segment_id TEXT,object_id TEXT,geometry_json TEXT,source_revision_id TEXT);
CREATE TABLE pavement_observations(observation_id TEXT PRIMARY KEY,street_key TEXT,on_street TEXT,from_street TEXT,to_street TEXT,rating REAL,display_condition TEXT,inspection_at TEXT,non_rating_reason TEXT,direction TEXT,road_type TEXT,geometry_json TEXT,source_revision_id TEXT,source_row_key TEXT);
CREATE TABLE permits(permit_id TEXT PRIMARY KEY,on_street_key TEXT,from_street_key TEXT,to_street_key TEXT,on_street TEXT,from_street TEXT,to_street TEXT,permit_number TEXT,permit_type TEXT,permit_status TEXT,issue_date TEXT,valid_from TEXT,valid_to TEXT,source_revision_id TEXT);
CREATE TABLE permit_street_mentions(street_key TEXT,permit_id TEXT,role TEXT,PRIMARY KEY(street_key,permit_id,role));
CREATE TABLE pavement_road_candidates(road_id TEXT,observation_id TEXT,match_status TEXT,matching_method TEXT,PRIMARY KEY(road_id,observation_id));
CREATE INDEX roads_by_street ON roads(street_key); CREATE INDEX obs_by_street ON pavement_observations(street_key,inspection_at DESC);
CREATE INDEX permits_by_on_street ON permits(on_street_key,issue_date DESC); CREATE INDEX mentions_by_street ON permit_street_mentions(street_key,role);
CREATE INDEX candidates_by_road ON pavement_road_candidates(road_id);
''')
def norm(x):return ' '.join(re.sub(r'[^A-Z0-9]+',' ',(x or '').upper()).split())
def cat(v):
 if v is None:return None
 if v<1 or v>10:return 'Unclassified'
 return 'Poor' if v<4 else 'Fair' if v<8 else 'Good'
street_names={}
roadbatch=[];obsbatch=[];permitbatch=[];mentions=[]
for kind,rid,rev,st,rating,inspection,geometry,payload in s.execute('SELECT kind,id,source_revision_id,street_name,rating,inspection_at,geometry_json,record_json FROM records'):
 d=json.loads(payload);v=d['values'];ident=d.get('raw_identifiers') or {}
 if kind=='road':
  key=norm(v.get('name') or st);street_names.setdefault(key,v.get('name') or st)
  roadbatch.append((rid,key,v.get('name') or st,ident.get('segment_id'),ident.get('object_id'),geometry,rev))
 elif kind=='condition':
  key=norm(v.get('on_street') or st)
  if not key:continue
  x=v.get('rating');r=None
  try:r=float(x) if x is not None else None
  except (ValueError,TypeError):pass
  obsbatch.append((rid,key,v.get('on_street'),v.get('from_street'),v.get('to_street'),r,cat(r),v.get('inspection_at'),v.get('non_rating_reason'),v.get('direction'),v.get('road_type'),geometry,rev,ident.get('source_row_id')))
 elif kind=='permit':
  keys=[norm(v.get(a)) for a in ['on_street','from_street','to_street']]
  permitbatch.append((rid,*keys,v.get('on_street'),v.get('from_street'),v.get('to_street'),ident.get('permit_number'),v.get('permit_type'),v.get('permit_status'),v.get('issued_at'),v.get('valid_from'),v.get('valid_to'),rev))
  for key,role in zip(keys,['on_street','from_cross_street','to_cross_street']):
   if key:mentions.append((key,rid,role))
print('Parsed',len(roadbatch),len(obsbatch),len(permitbatch),len(mentions),flush=True)
o.executemany('INSERT INTO roads VALUES (?,?,?,?,?,?,?)',roadbatch)
o.executemany('INSERT INTO pavement_observations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',obsbatch)
o.executemany('INSERT INTO permits VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',permitbatch)
o.executemany('INSERT OR IGNORE INTO permit_street_mentions VALUES (?,?,?)',mentions)
# Existing candidates remain cross-reference evidence; do not imply approval.
o.executemany('INSERT INTO pavement_road_candidates VALUES (?,?,?,?)',s.execute('SELECT road_id,observation_id,match_status,matching_method FROM road_observations'))
for k,n in street_names.items():o.execute('INSERT INTO streets(street_key,display_name) VALUES (?,?)',(k,n))
# All records named in the actual data, including those outside the selected geographic road scope, are retained;
# street summaries are restricted to names occurring in LION coverage.
o.executescript('''
UPDATE streets SET road_segments=(SELECT count(*) FROM roads WHERE street_key=streets.street_key),
 observations=(SELECT count(*) FROM pavement_observations WHERE street_key=streets.street_key),
 permits_on_street=(SELECT count(*) FROM permits WHERE on_street_key=streets.street_key),
 permits_other_mentions=(SELECT count(DISTINCT permit_id) FROM permit_street_mentions WHERE street_key=streets.street_key AND role!='on_street');
UPDATE streets SET latest_inspection_at=(SELECT max(inspection_at) FROM pavement_observations WHERE street_key=streets.street_key AND rating IS NOT NULL AND non_rating_reason IS NULL);
UPDATE streets SET latest_rating=(SELECT rating FROM pavement_observations WHERE street_key=streets.street_key AND inspection_at=streets.latest_inspection_at AND rating IS NOT NULL AND non_rating_reason IS NULL ORDER BY observation_id LIMIT 1);
UPDATE streets SET display_condition= CASE WHEN latest_rating IS NULL THEN 'Unknown' WHEN latest_rating < 1 OR latest_rating > 10 THEN 'Unclassified' WHEN latest_rating < 4 THEN 'Poor' WHEN latest_rating < 8 THEN 'Fair' ELSE 'Good' END,
 display_basis=CASE WHEN latest_rating IS NULL THEN 'No usable named-street pavement observation' ELSE 'Most recent named-street DOT pavement observation; indicative, not a verified whole-road or segment-wide condition' END;
CREATE VIEW road_profiles AS SELECT r.road_id,r.street_key,r.street_name,r.segment_id,r.object_id,r.geometry_json,st.observations AS street_observation_count,st.permits_on_street,st.permits_other_mentions,st.latest_rating,st.latest_inspection_at,st.display_condition,st.display_basis FROM roads r JOIN streets st USING(street_key);
CREATE VIEW road_permits_by_name AS SELECT r.road_id,p.permit_id,p.permit_number,p.permit_type,p.permit_status,p.on_street,p.from_street,p.to_street,p.issue_date,p.valid_from,p.valid_to,'on_street_name' AS association_basis FROM roads r JOIN permits p ON p.on_street_key=r.street_key;
CREATE VIEW road_pavement_by_name AS SELECT r.road_id,o.observation_id,o.on_street,o.from_street,o.to_street,o.rating,o.display_condition,o.inspection_at,o.geometry_json,'on_street_name' AS association_basis FROM roads r JOIN pavement_observations o ON o.street_key=r.street_key;
''')
meta={'source_snapshot':'nyc-4620b9e30c1c0bd5be4252fe27999c80','source_file':'User-uploaded CivicPlAIn pilot; normalized from CivicPlAIn_NYC_unified.sqlite3','rule':'Match normalized on_street to normalized LION street name; cross-street mentions in separate table','condition_bands':'App-facing indicative: 1 <= rating < 4 Poor, 4 <= rating < 8 Fair, 8 <= rating <= 10 Good. This is NOT NYC official classification, and no road segment rating is verified.','permit_basis':'The permit names the road on on_street, not proven actual work on every segment of that street; issue/valid dates are administrative.','reference_date':'2026-11-08','dataset_kind':'derived_read_only_road_lookup'}
o.executemany('INSERT INTO metadata VALUES (?,?)',[(k,json.dumps(v)) for k,v in meta.items()]);o.commit();print('Integrity',o.execute('PRAGMA integrity_check').fetchone(),flush=True)
for t in ('streets','roads','pavement_observations','permits','permit_street_mentions','pavement_road_candidates'):
 print(t,o.execute('SELECT count(*) FROM '+t).fetchone()[0],flush=True)
print('coverage',o.execute("SELECT count(*),sum(observations>0),sum(permits_on_street>0),sum(observations>0 AND permits_on_street>0) FROM streets").fetchone(),flush=True)
print('white',o.execute("select * from streets where street_key='WHITE STREET'").fetchone(),flush=True)
o.execute('VACUUM');o.close();s.close()
